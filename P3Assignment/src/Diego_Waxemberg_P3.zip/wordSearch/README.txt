Run the program with two arguments, input and output files, respectively.
The main method uses the first two indexes in args as the input and output
files respectively. 
It will then create an instance of my class, read the input file,
create a hash table, print the hash table to the console with the average collision length, 
and write the hash table to the output file.
I have included a toy file named, "toy.txt" that I ran my program on and the produced output file, 
"toy.hash" (open with a text editor). 
